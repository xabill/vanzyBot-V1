name: ✨ Feature Request
description: Minta fitur baru untuk VanzyBot-V1
title: "[FEATURE] - "
labels: ["enhancement"]
assignees: []

body:
  - type: markdown
    attributes:
      value: |
        ## ✨ VanzyBot-V1 Feature Request
        Terima kasih sudah memberikan ide fitur baru 🚀
        Silakan isi form di bawah dengan jelas agar mudah dipahami developer.

  - type: input
    id: username
    attributes:
      label: 👤 Username GitHub
      placeholder: ex. vanzydev
    validations:
      required: true

  - type: textarea
    id: feature_description
    attributes:
      label: 💡 Deskripsi Fitur
      description: Jelaskan fitur yang kamu mau
      placeholder: Tambahkan fitur auto downloader TikTok tanpa watermark
    validations:
      required: true

  - type: textarea
    id: problem
    attributes:
      label: ❓ Problem / Kebutuhan
      description: Kenapa fitur ini dibutuhkan?
      placeholder: Agar user bisa download video lebih cepat tanpa aplikasi tambahan

  - type: textarea
    id: solution
    attributes:
      label: 💭 Ide Solusi
      description: Jelaskan cara kerja fitur (kalau ada ide)
      placeholder: Bot mengambil API lalu mengirim file langsung ke WhatsApp

  - type: textarea
    id: commands
    attributes:
      label: ⚙️ Contoh Command
      description: Contoh command yang diinginkan
      placeholder: |
        .tiktok <url>
        .ytmp4 <url>
        .ai <text>

  - type: dropdown
    id: priority
    attributes:
      label: 🚀 Prioritas Fitur
      options:
        - Low (nice to have)
        - Medium (useful)
        - High (very important)
    validations:
      required: true

  - type: checkboxes
    id: checklist
    attributes:
      label: ✅ Checklist
      options:
        - label: Fitur ini belum ada di bot
        - label: Saya sudah cek issue lain
        - label: Fitur ini bermanfaat untuk banyak user
          required: true