name: 🐛 Bug Report
description: Laporkan bug/error pada VanzyBot-V1
title: "[BUG] - "
labels: ["bug"]
assignees: []

body:
  - type: markdown
    attributes:
      value: |
        ## 🐛 VanzyBot-V1 Bug Report
        Terima kasih sudah melaporkan bug. Mohon isi form di bawah dengan jelas agar mudah diperbaiki.

  - type: input
    id: username
    attributes:
      label: 👤 Username GitHub
      description: Siapa yang melaporkan bug?
      placeholder: ex. vanzydev
    validations:
      required: true

  - type: textarea
    id: bug_description
    attributes:
      label: 📌 Deskripsi Bug
      description: Jelaskan bug yang terjadi
      placeholder: Bot error saat menjalankan command .menu
    validations:
      required: true

  - type: textarea
    id: steps
    attributes:
      label: 🔁 Cara Reproduce
      description: Langkah untuk memunculkan bug
      placeholder: |
        1. Jalankan bot
        2. Kirim command .menu
        3. Bot crash
    validations:
      required: true

  - type: textarea
    id: expected
    attributes:
      label: 🎯 Hasil yang diharapkan
      placeholder: Bot harus menampilkan menu

  - type: textarea
    id: actual
    attributes:
      label: 💥 Hasil yang terjadi
      placeholder: Bot tidak merespon / crash

  - type: dropdown
    id: severity
    attributes:
      label: ⚠️ Tingkat Bug
      options:
        - Low (minor issue)
        - Medium (mengganggu fitur)
        - High (bot crash / error total)
    validations:
      required: true

  - type: textarea
    id: logs
    attributes:
      label: 📄 Log/Error
      description: Copy paste error log (jika ada)
      render: shell

  - type: checkboxes
    id: checklist
    attributes:
      label: ✅ Checklist
      options:
        - label: Saya sudah cek bug ini belum ada di issue lain
        - label: Saya sudah coba restart bot
        - label: Saya yakin ini bug dari sistem bot
          required: true